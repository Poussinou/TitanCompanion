package pt.joaomneto.titancompanion.adventure.impl

class IOTLKAdventure : TFODAdventure()
