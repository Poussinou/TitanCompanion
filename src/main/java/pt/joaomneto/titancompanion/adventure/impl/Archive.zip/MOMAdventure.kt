package pt.joaomneto.titancompanion.adventure.impl

class MOMAdventure : TFODAdventure()
