package pt.joaomneto.titancompanion.adventure.impl

class BWAdventure : EOTDAdventure()
